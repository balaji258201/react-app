import React, { useState, useEffect } from 'react';
import '../App.css';

// Modal component defined locally within UserDetails component
const Modal = ({ details, isOpen, onClose, handleSubmit }) => {
  const [updatedDetails, setUpdatedDetails] = useState(details);

  useEffect(() => {
    setUpdatedDetails(details);
  }, [details]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUpdatedDetails(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleModalSubmit = (e) => {
    e.preventDefault();
    handleSubmit(updatedDetails);
  };

  return (
    <>
      {isOpen && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={onClose}>&times;</span>
            <h2>Update Details</h2>
            <form onSubmit={handleModalSubmit}>
              <label>
                First Name:
                <input type="text" name="firstName" value={updatedDetails.firstName} onChange={handleChange} readOnly required />
              </label>
              <br />
              <label>
                Last Name:
                <input type="text" name="lastName" value={updatedDetails.lastName} onChange={handleChange} readOnly required />
              </label>
              <br />
              <label>
                Email:
                <input type="email" name="email" value={updatedDetails.email} onChange={handleChange} required />
              </label>
              <br />
              <label>
                Phone:
                <input type="text" name="phone" value={updatedDetails.phone} onChange={handleChange} pattern="[0-9]{10}" required />
              </label>
              <br />
              <button type="submit">Update</button>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

const DeleteConfirmationModal = ({ isOpen, onClose, handleDelete }) => {
  return (
    <>
      {isOpen && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={onClose}>&times;</span>
            <h2>Are you sure you want to delete this user?</h2>
            <button onClick={handleDelete}>Yes</button>
            <button onClick={onClose}>No</button>
          </div>
        </div>
      )}
    </>
  );
};

const UserDetails = () => {
  const initialDetails = {
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
  };

  const [details, setDetails] = useState(initialDetails);
  const [submittedDetails, setSubmittedDetails] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('home');
  const [deleteDetails, setDeleteDetails] = useState(null);

  useEffect(() => {
    const storedDetails = JSON.parse(localStorage.getItem('submittedDetails')) || [];
    setSubmittedDetails(storedDetails);
  }, []);

  useEffect(() => {
    localStorage.setItem('submittedDetails', JSON.stringify(submittedDetails));
  }, [submittedDetails]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setDetails(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = (updatedDetails) => {
    const index = submittedDetails.findIndex(item => item.firstName === updatedDetails.firstName && item.lastName === updatedDetails.lastName);
    if (index !== -1) {
      const updatedList = [...submittedDetails];
      updatedList[index] = { ...updatedList[index], email: updatedDetails.email, phone: updatedDetails.phone };
      setSubmittedDetails(updatedList);
      setModalOpen(false);
    }
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();

    if (!validateEmail(details.email)) {
      alert('Please enter a valid email address.');
      return;
    }

    if (isEmailUnique(details.email, details.firstName, details.lastName)) {
      alert('Email address already exists.');
      return;
    }

    setSubmittedDetails([...submittedDetails, details]);
    setDetails(initialDetails); // Reset form fields
    setActiveTab('home'); // Redirect to home tab to show updated user list
  };

  const handleLogout = () => {
    window.location.href = '/';
  };

  const validateEmail = (email) => {
    const re = /\S+@\S+\.\S+/;
    return re.test(email);
  };

  const isEmailUnique = (email, firstName, lastName) => {
    return submittedDetails.some(item => item.email === email && (item.firstName !== firstName || item.lastName !== lastName));
  };

  const handleDelete = () => {
    const updatedList = submittedDetails.filter(item => item.firstName !== deleteDetails.firstName || item.lastName !== deleteDetails.lastName);
    setSubmittedDetails(updatedList);
    setDeleteModalOpen(false);
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'addUser':
        return (
          <div>
            <h2>Add User</h2>
            <form onSubmit={handleFormSubmit}>
              <label>
                First Name:
                <input type="text" name="firstName" value={details.firstName} onChange={handleChange} required />
              </label>
              <br />
              <label>
                Last Name:
                <input type="text" name="lastName" value={details.lastName} onChange={handleChange} required />
              </label>
              <br />
              <label>
                Email:
                <input type="email" name="email" value={details.email} onChange={handleChange} required />
              </label>
              <br />
              <label>
                Phone:
                <input type="text" name="phone" value={details.phone} onChange={handleChange} pattern="[0-9]{10}" required />
              </label>
              <br />
              <button type="submit">Submit</button>
            </form>
          </div>
        );
      case 'updateUser':
        return (
          <div>
            <h2>Update User</h2>
            <table>
              <thead>
                <tr>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {submittedDetails.map((item, index) => (
                  <tr key={index}>
                    <td>{item.firstName}</td>
                    <td>{item.lastName}</td>
                    <td>{item.email}</td>
                    <td>{item.phone}</td>
                    <td>
                      <button onClick={() => openUpdateModal(item)}>Update</button>
                      <button onClick={() => openDeleteModal(item)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <Modal
              details={details}
              isOpen={modalOpen}
              onClose={() => setModalOpen(false)}
              handleSubmit={handleSubmit}
            />
            <DeleteConfirmationModal
              isOpen={deleteModalOpen}
              onClose={() => setDeleteModalOpen(false)}
              handleDelete={handleDelete}
            />
          </div>
        );
      case 'home':
      default:
        return (
          <div>
            <h2>Home - User Details</h2>
            <table>
              <thead>
                <tr>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {submittedDetails.map((item, index) => (
                  <tr key={index}>
                    <td>{item.firstName}</td>
                    <td>{item.lastName}</td>
                    <td>{item.email}</td>
                    <td>{item.phone}</td>
                    <td>
                      <button onClick={() => openUpdateModal(item)}>Update</button>
                      <button onClick={() => openDeleteModal(item)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <Modal
              details={details}
              isOpen={modalOpen}
              onClose={() => setModalOpen(false)}
              handleSubmit={handleSubmit}
            />
            <DeleteConfirmationModal
              isOpen={deleteModalOpen}
              onClose={() => setDeleteModalOpen(false)}
              handleDelete={handleDelete}
            />
          </div>
        );
    }
  };

  const openUpdateModal = (details) => {
    setDetails(details);
    setModalOpen(true);
  };

  const openDeleteModal = (details) => {
    setDeleteDetails(details);
    setDeleteModalOpen(true);
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="container">
      <h2>User Details Dashboard</h2>
      
      {/* Navigation Bar */}
      <div className="nav-bar">
        <button onClick={() => handleTabChange('home')}>Home</button>
        <button onClick={() => handleTabChange('addUser')}>Add User</button>
        <button onClick={() => handleTabChange('updateUser')}>Update User</button>
      </div>

      {/* Render content based on active tab */}
      {renderContent()}

      {/* Logout button */}
      <button onClick={handleLogout}>Logout</button>
    </div>
  );
};

export default UserDetails;
